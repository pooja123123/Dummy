package com.cg.spring.boot;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.dto.Product;
import com.cg.spring.service.ProductService;

@RestController
public class ProductController {
	@Autowired
	ProductService productService;

	/*
	 * public ProductController() { productService = new ProductServiceImpl(); }
	 */

	@RequestMapping("/Product/{id}")
	private Product getById (@PathVariable String id) {
		/* return productService.getAllProducts(); */
		return productService.getById(id);
	}

	@RequestMapping("/Product")
	private List<Product> show1() {
		/* return productService.getAllProducts(); */
		return productService.getAllProducts();
	}
	
	
	@RequestMapping(value="/Product",method=RequestMethod.POST)
	public void addProduct(@RequestBody Product p)
	{
		productService.addProduct(p);
	}
	@DeleteMapping(value="/Product/{id}")
	public void deleteProduct(@PathVariable String id)
	{
		 productService.deleteProduct(id);
	}
	@RequestMapping(value="/Product/{id}",method=RequestMethod.PUT)
	public void updateProduct(@RequestBody Product p,@PathVariable String id) {
		productService.updateProduct(p,id);
	}
}
