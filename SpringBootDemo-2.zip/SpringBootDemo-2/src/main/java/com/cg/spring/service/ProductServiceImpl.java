package com.cg.spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.dto.Product;
import com.cg.spring.repo.ProductRepo;


@Service("productservice")
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo productrepo;

	/*public ProductServiceImpl() {

		productrepo = new ProductRepoImpl();
	}*/

	@Override
	public List<Product> getAllProducts() {

		return productrepo.getAllProducts();
	}

	@Override
	public Product getById(String id) {

		return productrepo.getById(id);
	}

	@Override
	public void addProduct(Product p) {
		productrepo.addProduct(p);
		
	}

	@Override
	public void updateProduct(Product p,String id) {
		productrepo.updateProduct(p,id);
		
	}

	@Override
	public void deleteProduct(String id) {
	productrepo.deleteProduct(id);
		
	}

}
