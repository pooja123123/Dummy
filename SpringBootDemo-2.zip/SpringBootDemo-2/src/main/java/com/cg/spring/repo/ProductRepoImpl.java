package com.cg.spring.repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.spring.dto.Product;

@Repository("productrepo")
public class ProductRepoImpl implements ProductRepo {
	public static List<Product> product = null;

	public ProductRepoImpl() {
		product = new ArrayList<>();
		Product p1 = new Product();
		p1.setId("123");
		p1.setModel("a");
		p1.setName("p1");
		p1.setPrice(20.0);
		product.add(p1);
		Product p12 = new Product();
		p12.setId("456");
		p12.setModel("q");
		p12.setName("p12");
		p12.setPrice(50.0);
		product.add(p12);

	}

	@Override
	public List<Product> getAllProducts() {
		return product;
	}

	@Override
	public Product getById(String id) {
		Product psearch = null;
		for (Product p : product) {
			if (p.getId().equals(id)) {
				psearch = p;
			}
		}
		return psearch;
	}

	@Override
	public void addProduct(Product p) {
		product.add(p);
		
	}

	@Override
	public void updateProduct(Product p,String id) {
		
		for(int i=0;i<product.size();i++)
		{
			if(product.get(i).getId().equals(id))
			{
				product.set(i, p);
			}
		}
		
	}

	@Override
	public void deleteProduct(String id) {
		Product psearch = null;
		for (Product p : product) {
			if (p.getId().equals(id)) {
				psearch = p;
			break;}
		}
		product.remove(psearch);
		
	}

	

}
