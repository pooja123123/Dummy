package com.cg.SpringDataJPA.Exception;

public class ProductExceptionC extends Exception {
	
	private static final long serialVersionUID = 1L;
	public ProductExceptionC(){
		super();
	}
	public ProductExceptionC(String msg){
		super(msg);
	}

}
