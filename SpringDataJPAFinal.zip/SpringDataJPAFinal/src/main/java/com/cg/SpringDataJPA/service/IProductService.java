package com.cg.SpringDataJPA.service;

import java.util.List;
import java.util.Optional;

import com.cg.SpringDataJPA.Exception.ProductExceptionC;
import com.cg.SpringDataJPA.beans.Product;

public interface IProductService {

	public List<Product> getAllProduct();

	public Optional<Product> getProductById(int id);

	public void addProduct(Product product);

	public String updateProduct(Product product, int id)
			throws ProductExceptionC;

	String deleteProduct(int id) throws ProductExceptionC;

}
